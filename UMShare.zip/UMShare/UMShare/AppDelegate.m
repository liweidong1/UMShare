//
//  AppDelegate.m
//  UMShare
//
//  Created by liweidong on 17/8/24.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "AppDelegate.h"
#import <UMSocialCore/UMSocialCore.h>


#define UM_APPKEY         @"5861e5daf5ade41326001eab"

#define WECHAT_APPKEY     @"wxdc1e388c3822c80b"                               //URL Schemes : wxdc1e388c3822c80b
#define WECHAT_APPSECRET  @"38dd8e643992c50d9c1f2b810cc36f02"

#define QQ_APPKEY         @"1105821097"                                       //URL Schemes : tencent1105821097

#define SINA_APPKEY       @"3921700954"                                       //URL Schemes : wb3921700954
#define SINA_APPSECRET    @"04b48b094faeb16683c32669824ebdad"
#define SINA_REDIRECTURL  @"https://sns.whalecloud.com/sina2/callback"

#define ALIPAY_APPKEY      @"2015111700822536"                                //URL Schemes : ap2015111700822536

 

//#define UM_APPKEY  @"59632ee6c62dca4fda0000fa"
//
//#define WECHAT_APPKEY  @"wx9bc30a44b861048e"
//#define WECHAT_APPSECRET  @"3baf1193c85774b3fd9d18447d76cab0"
//
//#define QQ_APPKEY         @"1105821097"
//
//#define SINA_APPKEY  @"467298458"
//#define SINA_APPSECRET  @"e7a353024736af26107f67f45d628566"
//#define SINA_REDIRECTURL  @"https://sns.whalecloud.com/sina2/callback"
//
//#define ALIPAY_APPKEY      @"2015111700822536"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    /* 打开调试日志 */
    [[UMSocialManager defaultManager] openLog:YES];
    
    /* 设置友盟appkey */
    [[UMSocialManager defaultManager] setUmSocialAppkey:UM_APPKEY];
    
    [self configUSharePlatforms];
    
    [self confitUShareSettings];

    return YES;
}
- (void)confitUShareSettings
    {
        /*
         * 打开图片水印
         */
        //[UMSocialGlobal shareInstance].isUsingWaterMark = YES;
        
        /*
         * 关闭强制验证https，可允许http图片分享，但需要在info.plist设置安全域名
         <key>NSAppTransportSecurity</key>
         <dict>
         <key>NSAllowsArbitraryLoads</key>
         <true/>
         </dict>
         */
        //[UMSocialGlobal shareInstance].isUsingHttpsWhenShareContent = NO;
        
    }
    
- (void)configUSharePlatforms
{
    /*
     设置微信的appKey和appSecret
     [微信平台从U-Share 4/5升级说明]http://dev.umeng.com/social/ios/%E8%BF%9B%E9%98%B6%E6%96%87%E6%A1%A3#1_1
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:WECHAT_APPKEY appSecret:WECHAT_APPSECRET redirectURL:nil];
    /*
     * 移除相应平台的分享，如微信收藏
     */
    //[[UMSocialManager defaultManager] removePlatformProviderWithPlatformTypes:@[@(UMSocialPlatformType_WechatFavorite)]];
    
    /* 设置分享到QQ互联的appID
     * U-Share SDK为了兼容大部分平台命名，统一用appKey和appSecret进行参数设置，而QQ平台仅需将appID作为U-Share的appKey参数传进即可。
     100424468.no permission of union id
     [QQ/QZone平台集成说明]http://dev.umeng.com/social/ios/%E8%BF%9B%E9%98%B6%E6%96%87%E6%A1%A3#1_3
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:QQ_APPKEY/*设置QQ平台的appID*/  appSecret:nil redirectURL:nil];
    
    /*
     设置新浪的appKey和appSecret
     [新浪微博集成说明]http://dev.umeng.com/social/ios/%E8%BF%9B%E9%98%B6%E6%96%87%E6%A1%A3#1_2
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Sina appKey:SINA_APPKEY  appSecret:SINA_APPSECRET redirectURL:SINA_REDIRECTURL];

    
    /* 支付宝的appKey */
    [[UMSocialManager defaultManager] setPlaform: UMSocialPlatformType_AlipaySession appKey:ALIPAY_APPKEY appSecret:nil redirectURL:nil];

    

        
}

    
    
    //#define __IPHONE_10_0    100000
#if __IPHONE_OS_VERSION_MAX_ALLOWED > 100000
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options
    {
        //6.3的新的API调用，是为了兼容国外平台(例如:新版facebookSDK,VK等)的调用[如果用6.2的api调用会没有回调],对国内平台没有影响。
        BOOL result = [[UMSocialManager defaultManager]  handleOpenURL:url options:options];
        if (!result) {
            // 其他如支付等SDK的回调
        }
        return result;
    }
    
#endif
    
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
    {
        //6.3的新的API调用，是为了兼容国外平台(例如:新版facebookSDK,VK等)的调用[如果用6.2的api调用会没有回调],对国内平台没有影响
        BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url sourceApplication:sourceApplication annotation:annotation];
        if (!result) {
            // 其他如支付等SDK的回调
        }
        return result;
    }
    
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
    {
        BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
        if (!result) {
            // 其他如支付等SDK的回调
        }
        return result;
    }

    
- (void)applicationWillResignActive:(UIApplication *)application {
  }


- (void)applicationDidEnterBackground:(UIApplication *)application {

}


- (void)applicationWillEnterForeground:(UIApplication *)application {

}


- (void)applicationDidBecomeActive:(UIApplication *)application {
  
}


- (void)applicationWillTerminate:(UIApplication *)application {
   
}


@end
