//
//  ViewController.m
//  UMShare
//
//  Created by liweidong on 17/8/24.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import <UShareUI/UShareUI.h>
#import "UMShareTypeViewController.h"

@interface ViewController ()<UMSocialShareMenuViewDelegate>

@end

@implementation ViewController
- (IBAction)showShare:(id)sender {
    [UMSocialUIManager removeAllCustomPlatformWithoutFilted];
    [UMSocialShareUIConfig shareInstance].sharePageGroupViewConfig.sharePageGroupViewPostionType = UMSocialSharePageGroupViewPositionType_Bottom;
    [UMSocialShareUIConfig shareInstance].sharePageScrollViewConfig.shareScrollViewPageItemStyleType = UMSocialPlatformItemViewBackgroudType_None;
        [UMSocialUIManager showShareMenuViewInWindowWithPlatformSelectionBlock:^(UMSocialPlatformType platformType, NSDictionary *userInfo) {
            [self runShareWithType:platformType];
        }];
}
 - (void)runShareWithType:(UMSocialPlatformType)type
{
    UMShareTypeViewController *VC = [[UMShareTypeViewController alloc] initWithType:type];
    [self.navigationController pushViewController:VC animated:YES];
}
 
 
 - (UILabel *)labelWithName:(NSString *)name
{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0.f, 0.f, 140.f, 33.f)];
    label.font = [UIFont systemFontOfSize:16.f];
    label.textAlignment = NSTextAlignmentLeft;
    label.text = name;
    label.textColor = [UIColor colorWithRed:0.f green:0.53f blue:0.86f alpha:1.f];
    return label;
}
 
 - (UIButton *)button
{
    CGRect frame = self.view.frame;
    CGFloat width = frame.size.width - 20.f * 4;
    width /= 2;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(250.f, 10.f, width, width / 3);
    button.backgroundColor = [UIColor whiteColor];
    [button setTitleColor:[UIColor colorWithRed:0.34 green:.35 blue:.3 alpha:1] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:16.f];
    
    return button;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //设置用户自定义的平台
    [UMSocialUIManager setPreDefinePlatforms:@[@(UMSocialPlatformType_WechatSession),
                                               @(UMSocialPlatformType_WechatTimeLine),
                                               @(UMSocialPlatformType_QQ),
                                               @(UMSocialPlatformType_Qzone),
                                               @(UMSocialPlatformType_Sina),
                                               @(UMSocialPlatformType_AlipaySession),
    ]];
}


#pragma mark - UMSocialShareMenuViewDelegate
- (void)UMSocialShareMenuViewDidAppear
    {
        NSLog(@"UMSocialShareMenuViewDidAppear");
    }
- (void)UMSocialShareMenuViewDidDisappear
    {
        NSLog(@"UMSocialShareMenuViewDidDisappear");
    }
    
    //不需要改变父窗口则不需要重写此协议
- (UIView*)UMSocialParentView:(UIView*)defaultSuperView
    {
        return defaultSuperView;
    }
@end
