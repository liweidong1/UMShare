//
//  UShareUI.h
//  UShareUI
//
//  Created by wyq.Cloudayc on 11/24/16.
//  Copyright © 2016 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UShareUI.
FOUNDATION_EXPORT double UShareUIVersionNumber;

//! Project version string for UShareUI.
FOUNDATION_EXPORT const unsigned char UShareUIVersionString[];


#import <UShareUI/UMSocialUIManager.h>
#import <UShareUI/UMSocialShareUIConfig.h>

