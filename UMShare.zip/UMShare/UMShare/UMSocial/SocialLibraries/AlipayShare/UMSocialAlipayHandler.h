//
//  UMSAlipayShareTableViewController.h
//  SocialSDK
//
//  Created by umeng on 16/4/18.
//  Copyright © 2016年 dongjianxiong. All rights reserved.
//

#import <UMSocialCore/UMSocialCore.h>

@interface UMSocialAlipayHandler : UMSocialHandler


+ (UMSocialAlipayHandler *)defaultManager;


@end
